import grpc.server.Server as server
import grpc.client.Client as client


def main():
    print("tu")
    ##execfile('src\grpc\server\Server.py')

###if __name__ == "__main__":
###    main(sys.argv[1], sys.argv[2], sys.argv[3])
