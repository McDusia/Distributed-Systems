
from __future__ import print_function

import grpc
import currencyExchange_pb2 as c
import currencyExchange_pb2_grpc as ce


def run():
    print('tam')
    channel = grpc.insecure_channel('localhost:50051')
    stub = ce.CurrencyExchangeStub(channel)
    response = stub.Count(c.ExchangeArguments(currencyType=c.PLN))
    result = response

    for r in result:
        print("tu")
        print("Feature called", r)

    print("Greeter server received: %d", result)


if __name__ == '__main__':
    run()
