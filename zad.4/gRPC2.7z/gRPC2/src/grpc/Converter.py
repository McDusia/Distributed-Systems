
import random


def convert(from_curr, to_curr):

    exchange = {'USD': {'PLN': 3.56, 'EUR': 0.83},
                'PLN': {'USD': 0.28, 'EUR': 0.23},
                'EUR': {'USD': 1.20, 'PLN': 4.27}}

    random_change = random.uniform(0, 0.4)

    result = exchange[from_curr][to_curr] + random_change

    return round(result, 4)
