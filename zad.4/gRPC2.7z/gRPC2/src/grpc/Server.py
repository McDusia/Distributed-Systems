import math
from concurrent import futures

import time
import grpc
import currencyExchange_pb2 as c
import currencyExchange_pb2_grpc as ce
import thread
import threading
from time import sleep
##import uuid

_ONE_HOUR_IN_SECONDS = 60 * 60

from Converter import convert


conversions = {0: 'PLN', 1: 'EUR', 2: 'USD'}

##def getNewGUID():
##    uuid.uuid4()

##(from_curr, to_curr='USD', amount=1.0, date=None)


class CurrencyExchangeServicer(ce.CurrencyExchangeServicer):
    def Count(self, request, context):
        from_curr_int = request.currencyType
        from_curr = conversions[from_curr_int]

        while True:
            for k, v in conversions.items():
                if k != from_curr_int:
                    converted = convert(from_curr, v)
                    print(converted)
                    result = int(converted * 10000)
                    yield c.CountedExchange(res=result)
            sleep(5)

        #for i in xrange(10):
        #    yield c.CountedExchange(res=i)


a_lock = thread.allocate_lock()
lock = threading.Lock()


def runner(arg):
    #with a_lock:
    lock.acquire()
    print 'running', arg
    sleep(1)
    lock.release()
    return


threads = []


def serve():
    print('tu')
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    ce.add_CurrencyExchangeServicer_to_server(CurrencyExchangeServicer(), server)
    server.add_insecure_port('[::]:50051')
    server.start()

    #converted = convert('EUR', 'USD')
    #print(converted)

    try:
        while True:
            time.sleep(_ONE_HOUR_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)


if __name__ == '__main__':
    #t = thread.start_new_thread(runner, 5)
    worker = threading.Thread(target=runner, args=(5,))
    worker.start()
    serve()
