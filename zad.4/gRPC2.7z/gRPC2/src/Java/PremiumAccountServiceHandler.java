package Java;

import org.apache.thrift.TException;
import thrift.bank.*;

public class PremiumAccountServiceHandler implements PremiumAccountService.Iface{

    private State state;

    PremiumAccountServiceHandler(State state) {
        this.state = state;
    }

    @Override
    public CreditCostsResult creditCosts(String GUID_number, CurrencyType currency, Period period) throws InvalidArguments, TException {
        //TODO
        return null;
    }

    @Override
    public double getAccountState(String GUID_number) throws TException {
        return new StandardAccountServiceHandler(state).getAccountState(GUID_number);
    }
}
