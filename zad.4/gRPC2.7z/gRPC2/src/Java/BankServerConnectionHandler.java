package Java;

import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadPoolServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;
import thrift.bank.AccountCreator;

public class BankServerConnectionHandler implements Runnable {

    private State state;
    BankServerConnectionHandler(State state){
        this.state = state;
    }

    public static void start(AccountCreator.Processor<AccountCreatorHandler> processor) {
        try {
            TServerTransport serverTransport = new TServerSocket(9090);
            //TServer server = new TSimpleServer(
            //      new TServer.Args(serverTransport).processor(processor));

            //Use this for a multithreaded server
            TServer server = new TThreadPoolServer(new
                    TThreadPoolServer.Args(serverTransport).processor(processor));

            System.out.println("Starting the server...");
            server.serve();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void run() {
        start(new AccountCreator.Processor<>(new AccountCreatorHandler(state)));
    }
}
