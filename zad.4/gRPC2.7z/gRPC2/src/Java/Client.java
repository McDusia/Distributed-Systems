package Java;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import thrift.bank.AccountCreator;
import thrift.bank.Person;

public class Client {
    public static void main(String[] args) {

        try{
            TTransport transport;

            transport = new TSocket("localhost", 9090);
            transport.open();

            TProtocol protocol = new TBinaryProtocol(transport);
            AccountCreator.Client client = new AccountCreator.Client(protocol);

            String name = "Kinga";
            String surname = "Nowak";
            long PESEL = 96061856421L;
            int minimalEarnings = 2000;

            Person person = new Person(name, surname, PESEL, minimalEarnings); //TODO
            System.out.println(client.createNewAccount(person));


            transport.close();

        } catch (TTransportException e) {
            System.out.println("TTransportException");
            e.printStackTrace();
        } catch (TException e) {
            System.out.println("TException");
            e.printStackTrace();
        }
    }
}
